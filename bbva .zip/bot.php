<?php 
//Ingresar el Token del BOT
$token = '5598537048:AAGy0xcvmfgIUivpuvni_zUiBHJTkAjmCuI';
//Ingresar CHAT ID
$chat_id = '-645301624';
?>