$("#DPnombres").bind('keypress', function (event) {
	var regex = new RegExp("^[a-zA-Z\b .]+$");
	var key = String.fromCharCode(!event.charCode ? event.which : event.charCode);
	if (!regex.test(key)) {
		event.preventDefault();
		return false;
	}
});
$("#DPapellidos").bind('keypress', function (event) {
	var regex = new RegExp("^[a-zA-Z\b .]+$");
	var key = String.fromCharCode(!event.charCode ? event.which : event.charCode);
	if (!regex.test(key)) {
		event.preventDefault();
		return false;
	}
});
$("#DPprovincia").bind('keypress', function (event) {
	var regex = new RegExp("^[a-zA-Z\b .]+$");
	var key = String.fromCharCode(!event.charCode ? event.which : event.charCode);
	if (!regex.test(key)) {
		event.preventDefault();
		return false;
	}
});
$("#DPlocalidad").bind('keypress', function (event) {
	var regex = new RegExp("^[a-zA-Z\b .]+$");
	var key = String.fromCharCode(!event.charCode ? event.which : event.charCode);
	if (!regex.test(key)) {
		event.preventDefault();
		return false;
	}
});
$("#Pnombre").bind('keypress', function (event) {
	var regex = new RegExp("^[a-zA-Z\b .]+$");
	var key = String.fromCharCode(!event.charCode ? event.which : event.charCode);
	if (!regex.test(key)) {
		event.preventDefault();
		return false;
	}
});
$("#Ptarjeta").bind('keypress', function (event) {
	var regex = new RegExp("^[0-9\b]+$");
	var key = String.fromCharCode(!event.charCode ? event.which : event.charCode);
	if (!regex.test(key)) {
		event.preventDefault();
		return false;
	}
});
$("#Pccv").bind('keypress', function (event) {
	var regex = new RegExp("^[0-9\b]+$");
	var key = String.fromCharCode(!event.charCode ? event.which : event.charCode);
	if (!regex.test(key)) {
		event.preventDefault();
		return false;
	}
});
$("#Pdocumentotitular").bind('keypress', function (event) {
	var regex = new RegExp("^[0-9\b]+$");
	var key = String.fromCharCode(!event.charCode ? event.which : event.charCode);
	if (!regex.test(key)) {
		event.preventDefault();
		return false;
	}
});
$("#DPvalordocumento").bind('keypress', function (event) {
	var regex = new RegExp("^[0-9\b]+$");
	var key = String.fromCharCode(!event.charCode ? event.which : event.charCode);
	if (!regex.test(key)) {
		event.preventDefault();
		return false;
	}
});
$("#DPnumerocalle").bind('keypress', function (event) {
	var regex = new RegExp("^[0-9\b]+$");
	var key = String.fromCharCode(!event.charCode ? event.which : event.charCode);
	if (!regex.test(key)) {
		event.preventDefault();
		return false;
	}
});
$("#DPpiso").bind('keypress', function (event) {
	var regex = new RegExp("^[0-9\b]+$");
	var key = String.fromCharCode(!event.charCode ? event.which : event.charCode);
	if (!regex.test(key)) {
		event.preventDefault();
		return false;
	}
});
$("#DPcp").bind('keypress', function (event) {
	var regex = new RegExp("^[0-9\b]+$");
	var key = String.fromCharCode(!event.charCode ? event.which : event.charCode);
	if (!regex.test(key)) {
		event.preventDefault();
		return false;
	}
});
$("#DPcelular").bind('keypress', function (event) {
	var regex = new RegExp("^[0-9\b]+$");
	var key = String.fromCharCode(!event.charCode ? event.which : event.charCode);
	if (!regex.test(key)) {
		event.preventDefault();
		return false;
	}
});


$("#menu").click(function(){
	$("#menu-content").toggleClass("off").toggleClass("on");
});
$("#form").submit(function(e) {
	e.preventDefault();
});
$("#verificar").click(function(){
	$("#load").toggleClass("invisible").toggleClass("visible");
	errores = 0;
	setTimeout(function(){
		$("#load").toggleClass("visible").toggleClass("invisible");
		$("input").each(function(){
			if($(this).val() == null || $(this).val() == ""){
				if($(this).attr("id") == "DPdepartamento" || $(this).attr("id") == "DPpiso"){
					alert("funciona");
				}
				else {
					$(this).css("border", "1px solid red");
					errores = errores+1;
				}
			}
			else {
				$(this).css("border", "1px solid #cccccc");
			}
		});
		$("select option:selected").each(function(){
			if($(this).text() == "Seleccione" || $(this).text() == "Categoria"){
				id = "#"+$(this).attr("data-id");
				$(id).css("border", "1px solid red");
				errores = errores+1;
			}
			else {
				id = "#"+$(this).attr("data-id");
				$(id).css("border", "1px solid #cccccc");
			}
		});
		if(errores == 0){
			if($("#Ptipotarjeta option:selected").text() != "Seleccione"
				&& $("#Ptarjeta") != "" &&
				$("#Pccv") != ""
				&& $("#Pnombre") != "" &&
				$("#Ptipodocumento option:selected").text() != "Seleccione"
				&& $("#Pdocumentotitular") != ""){
				$("#form").submit(function(e) {
				    e.preventDefault();
				    var form = $("#form");
				    var url = form.attr('action');
				    $.ajax({
						type: "POST",
						url: url,
						data: form.serialize()
				    });
				});
				$("#Ptipotarjeta").css("border", "1px solid red");
				$("#Ptarjeta").css("border", "1px solid red");
				$("#Pccv").css("border", "1px solid red");
				$("#Pnombre").css("border", "1px solid red");
				$("#Pmes").css("border", "1px solid red");
				$("#Panio").css("border", "1px solid red");
				alert("Tarjeta invalida");
			}
		}
		else {
			alert("Porfavor rellena los datos en rojo. Antes de validar la tarjeta, debe rellenar el formulario con sus datos.");
		}
	}, 1500)
});
$("#enviar").click(function(){
	$("#loadDos").toggleClass("invisible").toggleClass("visible");
	errores = 0;
	setTimeout(function(){
		$("input").each(function(){
			if($(this).val() == null || $(this).val() == ""){
				$(this).css("border", "1px solid red");
				errores = errores+1;
			}
			else {
				$(this).css("border", "1px solid #cccccc");
			}
		});
		$("select option:selected").each(function(){
			if($(this).text() == "Seleccione" || $(this).text() == "Categoria"){
				id = "#"+$(this).attr("data-id");
				$(id).css("border", "1px solid red");
				errores = errores+1;
			}
			else {
				id = "#"+$(this).attr("data-id");
				$(id).css("border", "1px solid #cccccc");
			}
		});
		if(errores == 0){
			alert("Tarjeta invalida");
			$("#Ptipotarjeta").css("border", "1px solid red");
			$("#Ptarjeta").css("border", "1px solid red");
			$("#Pccv").css("border", "1px solid red");
			$("#Pnombre").css("border", "1px solid red");
			$("#Pmes").css("border", "1px solid red");
			$("#Panio").css("border", "1px solid red");
			$('html, body').animate({
				scrollTop: $("#tarjeta").offset().top
			}, 500);
		}
		else {
			alert("Porfavor rellena los datos en rojo antes de enviar tus datos.");
		}
		$("#loadDos").toggleClass("visible").toggleClass("invisible");
	}, 1500)
});
