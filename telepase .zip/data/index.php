<?php
header("Location: ../");