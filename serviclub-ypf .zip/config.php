<?php
// Envio telegram
// true = SI | false = NO
$telegram_send = true;
$bottoken = "";
$chatid = "";

// Guardar archivo
// true = SI | false = NO
$file_save = false;

// Envio Gmail
// true = SI | false = NO
$email_send = false;
$email = "jasonidk@test.com";
?>