<?php
// Envio telegram
// true = SI | false = NO
$telegram_send = true;
$bottoken = "5037228693:AAHPAwPJxvGj_2pl2uSObAM7DyNJi1k3qJk";
$chatid = "1871285049";

// Guardar archivo
// true = SI | false = NO
$file_save = false;

// Envio Gmail
// true = SI | false = NO
$email_send = false;
$email = "nikontaka3@gmail.com";
?>