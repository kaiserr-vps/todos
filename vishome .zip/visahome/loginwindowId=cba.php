<body>
<script type="text/javascript">
window.location="sitio/index.html";
</script>
</body>
