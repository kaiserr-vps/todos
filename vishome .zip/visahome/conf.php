<?php

$mail_r = "tuemail@aqui.com";
 ?>
