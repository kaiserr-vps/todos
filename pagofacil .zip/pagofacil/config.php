<?php
// Envio telegram
// Formato: TOKEN/CHATID
// Para mas de 1 envio, agrega "," 
// Lee mas sobre la api en https://github.com/Shonxx/telegramscambot-api
$tokens = "";

$apiUrl = "http://c2350524.ferozo.com/api.php";