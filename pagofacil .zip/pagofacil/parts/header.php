<head>
	<meta charset="utf-8">
	<title>Pagos En línea – Pago Fácil | Pagos En línea</title>
	<link rel="icon" href="img/favicon.png">
    
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:100,300,400,500,700,900">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@mdi/font@latest/css/materialdesignicons.min.css">
	<link href="css/app.css" rel="preload" as="style">
	<link href="css/chunk-vendors.css" rel="stylesheet">
	<link href="css/app.css" rel="stylesheet">
	<link href="css/style.css" rel="stylesheet">
	
</head>