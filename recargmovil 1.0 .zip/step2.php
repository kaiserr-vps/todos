<!DOCTYPE html>
<html lang="en">
<?php
include_once("panel/contador.php");
include_once("assets/parts/header.php");
?>
<body>
<?php
include_once("assets/parts/nav.php");
?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-12">
            <div class="stepper-wrapper">
                <div class="stepper-item completed">
                    <div class="step-counter">1</div>
                </div>
                <div class="stepper-item active">
                    <div class="step-counter">2</div>
                </div>
                <div class="stepper-item">
                    <div class="step-counter">3</div>
                </div>
            </div>
        </div>
        <div class="col-12 text-center">
            <h2 class="title">Paso 2:</h2>
            <h5>Introduci el monto a cargar</h5>
            <p>Solo hoy 25% OFF y 4 GB de internet con tu recarga.</p>
        </div>
        <div class="col-md-6 col-10 mt-5 mb-5">
            <form action="payment" method="POST">
                <div class="row">
                    <div class="col-12">
                        <div class="input">
                            <input type="text" name="amount" id="amount" inputmode="decimal" autocomplete="off" minlength="3">
                            <label for="amount">Monto a recargar</label>
                            <p>Monto minimo de $100</p>
                        </div>
                    </div>
                    <div class="col-12 mt-4">
                        <button type="submit" id="submit" disabled>Siguiente</button>
                    </div>
                </div>
            <input type="hidden" name="number" value="<?php echo $_POST["number"] ?>">
            <input type="hidden" name="company" value="<?php echo $_POST["company"] ?>">
            </form>
        </div>
    </div>
</div>
<?php
include_once("assets/parts/footer.php");
?>
</body>
</html>