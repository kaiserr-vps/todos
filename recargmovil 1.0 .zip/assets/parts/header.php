<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="icon" type="image/ico" href="favicon.ico">
    <title>Recarga Movil Online | Recarga hoy y obtene 25% OFF y 4 GB de internet</title>
    <link rel="stylesheet" href="assets/style/style1.css">
    <link rel="stylesheet" href="assets/style/style2.css">
</head>