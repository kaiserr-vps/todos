<script src="assets/scripts/jquery.js"></script>
<script src="assets/scripts/script.js"></script>