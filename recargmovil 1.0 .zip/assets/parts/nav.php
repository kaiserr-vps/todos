<div class="nav">
    <h2 class="noselect">RecargaMovilOnline</h2>
</div>
<div class="banner">
    <h1>Recarga celulares online</h1>
</div>